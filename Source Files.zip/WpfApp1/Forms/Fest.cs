﻿using Ionic.Zip;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WpfApp1.Forms
{
    public partial class Fest : Form
    {
        public Fest()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WebClient webClient = new WebClient();
            string sourceFile = @"http://update.multiminer.us/CMUpdate/Wallets/Fest.zip";
            string destFile = @"C:/Miner/Tmp/Fest.zip";
            webClient.DownloadFileCompleted += new AsyncCompletedEventHandler(DownloadCompleted);
            webClient.DownloadProgressChanged += new DownloadProgressChangedEventHandler(ProgressChanged);
            webClient.DownloadFileAsync(new Uri(sourceFile), destFile);



        }

        private void ProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            progressBar1.Value = e.ProgressPercentage;
        }

        private void DownloadCompleted(object sender, AsyncCompletedEventArgs e)
        {
            {
                ZipFile zip = ZipFile.Read("C:\\Miner\\Tmp\\Fest.zip");
                Directory.CreateDirectory("C:\\Miner\\Wallets");
                zip.ExtractAll("C:\\Miner\\Wallets", ExtractExistingFileAction.OverwriteSilently);
            }
            MessageBox.Show("Download Complete!  The wallet will open shortly");
            Process.Start("C:/Miner/Wallets/Fest/fest.bat");
            {
                System.GC.Collect();
                System.GC.WaitForPendingFinalizers();
                File.Delete("C:/Miner/Tmp/Fest.zip");
            }
            this.Close();
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
