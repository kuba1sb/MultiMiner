﻿using Ionic.Zip;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WpfApp1.Forms
{
    public partial class ITNS : Form
    {
        public ITNS()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WebClient webClient = new WebClient();
            string sourceFile = @"http://update.multiminer.us/CMUpdate/Wallets/ITNS.zip";
            string destFile = @"C:/Miner/Tmp/ITNS.zip";
            webClient.DownloadFileCompleted += new AsyncCompletedEventHandler(DownloadCompleted);
            webClient.DownloadProgressChanged += new DownloadProgressChangedEventHandler(ProgressChanged);
            webClient.DownloadFileAsync(new Uri(sourceFile), destFile);



        }

        private void ProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            progressBar1.Value = e.ProgressPercentage;
        }

        private void DownloadCompleted(object sender, AsyncCompletedEventArgs e)
        {
            {
                ZipFile zip = ZipFile.Read("C:\\Miner\\Tmp\\ITNS.zip");
                Directory.CreateDirectory("C:\\Miner\\Wallets");
                zip.ExtractAll("C:\\Miner\\Wallets", ExtractExistingFileAction.OverwriteSilently);
            }
            MessageBox.Show("Download Complete!  The wallet will open shortly");
            Process.Start("C:/Miner/Wallets/ITNS/itns.cmd");
            {
                System.GC.Collect();
                System.GC.WaitForPendingFinalizers();
                File.Delete("C:/Miner/Tmp/ITNS.zip");
            }
            this.Close();
        }
    }
}
