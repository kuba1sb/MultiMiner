﻿using Ionic.Zip;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WpfApp1.Forms
{
    public partial class NBR : Form
    {
        public NBR()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WebClient webClient = new WebClient();
            string sourceFile = @"http://update.multiminer.us/CMUpdate/Wallets/NBR.zip";
            string destFile = @"C:/Miner/Tmp/NBR.zip";
            webClient.DownloadFileCompleted += new AsyncCompletedEventHandler(DownloadCompleted);
            webClient.DownloadProgressChanged += new DownloadProgressChangedEventHandler(ProgressChanged);
            webClient.DownloadFileAsync(new Uri(sourceFile), destFile);



        }

        private void ProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            progressBar1.Value = e.ProgressPercentage;
        }

        private void DownloadCompleted(object sender, AsyncCompletedEventArgs e)
        {
            {
                ZipFile zip = ZipFile.Read("C:\\Miner\\Tmp\\NBR.zip");
                Directory.CreateDirectory("C:\\Miner\\Wallets");
                zip.ExtractAll("C:\\Miner\\Wallets", ExtractExistingFileAction.OverwriteSilently);
            }
            MessageBox.Show("Download Complete!  The wallet will open shortly");
            Process.Start("C:/Miner/Wallets/NBR/niobio.exe");
            {
                System.GC.Collect();
                System.GC.WaitForPendingFinalizers();
                File.Delete("C:/Miner/Tmp/NBR.zip");
            }
            this.Close();
        }
    }
}
