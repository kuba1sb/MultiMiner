﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WpfApp1.Forms
{
    public partial class NewARQ: Form
    {
        public NewARQ()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                if (radioButton5.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/arq.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight_lite_v7 -o arq.multiminer.us:3333 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/arq.cmd");
                    this.Close();
                }
                else if (radioButton6.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/arq.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight_lite_v7 -o arq.multiminer.us:4444 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/arq.cmd");
                    this.Close();
                }
                else if (radioButton7.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/arq.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight_lite_v7 -o arq.multiminer.us:5555 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/arq.cmd");
                    this.Close();
                }
                else if (radioButton8.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the arq.multiminer.us pool", "ARQMA");
                }
                else if (radioButton9.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the arq.multiminer.us pool", "ARQMA");
                }
                else if (radioButton10.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the arq.multiminer.us pool", "ARQMA");
                }
                else if (radioButton11.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the arq.multiminer.us pool", "ARQMA");
                }
                else if (radioButton12.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the arq.multiminer.us pool", "ARQMA");
                }
                else if (radioButton13.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the arq.multiminer.us pool", "ARQMA");
                }
            }
            else if (radioButton2.Checked)
            {
                if (radioButton8.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/arq.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight_lite_v7 -o mine.arqma.com:3333 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/arq.cmd");
                    this.Close();
                }
                else if (radioButton9.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/arq.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight_lite_v7 -o mine.arqma.com:5555 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/arq.cmd");
                    this.Close();
                }
                else if (radioButton10.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/arq.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight_lite_v7 -o mine.arqma.com:7777 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/arq.cmd");
                    this.Close();
                }
                else if (radioButton5.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the mine.arqma.com pool", "ARQMA");
                }
                else if (radioButton6.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the mine.arqma.com pool", "ARQMA");
                }
                else if (radioButton7.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the mine.arqma.com pool", "ARQMA");
                }
                else if (radioButton11.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the mine.arqma.com pool", "ARQMA");
                }
                else if (radioButton12.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the mine.arqma.com pool", "ARQMA");
                }
                else if (radioButton13.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the mine.arqma.com pool", "ARQMA");
                }
            }
            else if (radioButton3.Checked)
            {
                if (radioButton11.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/arq.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight_lite_v7 -o arqma.herominers.com:10320 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/arq.cmd");
                    this.Close();
                }
                else if (radioButton12.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/arq.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight_lite_v7 -o arqma.herominers.com:10321 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/arq.cmd");
                    this.Close();
                }
                else if (radioButton13.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/arq.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight_lite_v7 -o arqma.herominers.com:10322 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/arq.cmd");
                    this.Close();
                }
                else if (radioButton5.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the arqma.herominers.com pool", "ARQMA");
                }
                else if (radioButton6.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the arqma.herominers.com pool", "ARQMA");
                }
                else if (radioButton7.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the arqma.herominers.com pool", "ARQMA");
                }
                else if (radioButton8.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the arqma.herominers.com pool", "ARQMA");
                }
                else if (radioButton9.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the arqma.herominers.com pool", "ARQMA");
                }
                else if (radioButton10.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the arqma.herominers.com pool", "ARQMA");
                }
            }
            else if (radioButton4.Checked)
            {
                using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/arq.cmd"))
                {
                    objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight_lite_v7 -o " + "" + textBox1.Text + ":" + textBox2.Text + " -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                    objWriter.WriteLine("exit");
                }
                Process.Start("C:/Miner/Configs/arq.cmd");
                this.Close();
            }
        }
    
        private void button3_Click(object sender, EventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/ARQ/arq.bat"))
            {
                System.Diagnostics.Process.Start("C:/Miner/Wallets/ARQ/arq.bat");
            }
            else
            {
                var myForm = new ARQ();
                myForm.Show();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
