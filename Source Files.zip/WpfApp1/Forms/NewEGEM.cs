﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WpfApp1.Forms
{
    public partial class NewEGEM : Form
    {
        public NewEGEM()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                if (radioButton5.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/egem.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\claymore\\EthDcrMiner64 -epool stratum+tcp://egem.protonmine.io:8008 -ewal " + textBox3.Text + " -psw " + textBox4.Text + " -allcoins 1 -mport -8080");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/egem.cmd");
                    this.Close();
                }
                else if (radioButton6.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/egem.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\claymore\\EthDcrMiner64 -epool stratum+tcp://egem.protonmine.io:8004 -ewal " + textBox3.Text + " -psw " + textBox4.Text + " -allcoins 1 -mport -8080");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/egem.cmd");
                    this.Close();
                }
                else if (radioButton8.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the protonmine.io pool", "EtherGem");
                }
                else if (radioButton9.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the protonmine.io pool", "EtherGem");
                }
            }
            else if (radioButton2.Checked)
            {
                if (radioButton8.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/egem.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\claymore\\EthDcrMiner64 -epool stratum+tcp://egem.minerpool.net:8001 -ewal " + textBox3.Text + " -psw " + textBox4.Text + " -allcoins 1 -mport -8080");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/egem.cmd");
                    this.Close();
                }
                else if (radioButton9.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/egem.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\claymore\\EthDcrMiner64 -epool stratum+tcp://egem.minerpool.net:8009 -ewal " + textBox3.Text + " -psw " + textBox4.Text + " -allcoins 1 -mport -8080");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/egem.cmd");
                    this.Close();
                }
                else if (radioButton5.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the minerpool.net pool", "EtherGem");
                }
                else if (radioButton6.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the minerpool.net pool", "EtherGem");
                }
            }
            else if (radioButton4.Checked)
            {
                using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/egem.cmd"))
                {
                    objWriter.WriteLine("start C:\\Miner\\Miners\\claymore\\EthDcrMiner64 -epool stratum+tcp://" + "" + textBox1.Text + ":" + textBox2.Text + " -ewal " + textBox3.Text + " -psw " + textBox4.Text + " -allcoins 1 -mport -8080");
                    objWriter.WriteLine("exit");
                }
                Process.Start("C:/Miner/Configs/egem.cmd");
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Process.Start("https://myegemwallet.com/");
        }
    }
}
