﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WpfApp1.Forms
{
    public partial class NewESN : Form
    {
        public NewESN()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                if (radioButton5.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/esn.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\claymore\\EthDcrMiner64.exe -epool stratum+tcp://esn.gonsmine.com:8008 -ewal " + textBox3.Text + " -epsw " + textBox4.Text + " -allcoins 1 -mport -8080");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/esn.cmd");
                    this.Close();
                }
                else if (radioButton8.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the esn.gonsmine.com pool", "Ether Social Network");
                }
            }
            else if (radioButton2.Checked)
            {
                if (radioButton8.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/esn.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\claymore\\EthDcrMiner64.exe -epool stratum+tcp://esn-kor1.topmining.co.kr:8008 -ewal " + textBox3.Text + " -epsw " + textBox4.Text + " -allcoins 1 -mport -8080");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/esn.cmd");
                    this.Close();
                }
                else if (radioButton5.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the topmining.co.kr pool", "Ether Social Network");
                }
            }
            else if (radioButton4.Checked)
            {
                using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/esn.cmd"))
                {
                    objWriter.WriteLine("start C:\\Miner\\Miners\\claymore\\EthDcrMiner64.exe -epool " + "" + textBox1.Text + ":" + textBox2.Text + " -ewal " + textBox3.Text + " -epsw " + textBox4.Text + " -allcoins 1 -mport -8080");
                    objWriter.WriteLine("exit");
                }
                Process.Start("C:/Miner/Configs/esn.cmd");
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Process.Start("https://wallet.gonspool.com/");
        }
    }
}
