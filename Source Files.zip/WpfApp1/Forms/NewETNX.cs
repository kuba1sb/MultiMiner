﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WpfApp1.Forms
{
    public partial class NewETNX : Form
    {
        public NewETNX()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                if (radioButton5.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/etnx.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency masari -o uspool.electronero.org:1122 -u " + textBox3.Text + " -p " + textBox4.Text + " -i 8080 -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/etnx.cmd");
                    this.Close();
                }
                else if (radioButton6.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/etnx.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency masari -o uspool.electronero.org:2233 -u " + textBox3.Text + " -p " + textBox4.Text + " -i 8080 -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/etnx.cmd");
                    this.Close();
                }
                else if (radioButton7.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/etnx.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency masari -o uspool.electronero.org:3344 -u " + textBox3.Text + " -p " + textBox4.Text + " -i 8080 -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/etnx.cmd");
                    this.Close();
                }
                else if (radioButton8.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the electronero.org pool", "Electronero");
                }
                else if (radioButton9.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the electronero.org pool", "Electronero");
                }
                else if (radioButton10.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the electronero.org pool", "Electronero");
                }
            }
            else if (radioButton2.Checked)
            {
                if (radioButton8.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/etnx.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency masari -o mine-etnx.thorshammer.cc:3333 -u " + textBox3.Text + " -p " + textBox4.Text + " -i 8080 -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/etnx.cmd");
                    this.Close();
                }
                else if (radioButton9.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/etnx.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency masari -o mine-etnx.thorshammer.cc:4444 -u " + textBox3.Text + " -p " + textBox4.Text + " -i 8080 -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/etnx.cmd");
                    this.Close();
                }
                else if (radioButton10.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/etnx.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency masari -o mine-etnx.thorshammer.cc:5555 -u " + textBox3.Text + " -p " + textBox4.Text + " -i 8080 -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/etnx.cmd");
                    this.Close();
                }
                else if (radioButton5.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the mine-etnx.thorshammer.cc pool", "Electronero");
                }
                else if (radioButton6.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the mine-etnx.thorshammer.cc pool", "Electronero");
                }
                else if (radioButton7.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the mine-etnx.thorshammer.cc pool", "Electronero");
                }
            }
            else if (radioButton4.Checked)
            {
                using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/etnx.cmd"))
                {
                    objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency masari -o " + "" + textBox1.Text + ":" + textBox2.Text + " -u " + textBox3.Text + " -p " + textBox4.Text + " -i 8080 -c C:\\Miner\\config.txt");
                    objWriter.WriteLine("exit");
                }
                Process.Start("C:/Miner/Configs/etnx.cmd");
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/ETNX/etnx.bat"))
            {
                System.Diagnostics.Process.Start("C:/Miner/Wallets/ETNX/etnx.bat");
            }
            else
            {
                var myForm = new ETNX();
                myForm.Show();
            }
        }
    }
}
