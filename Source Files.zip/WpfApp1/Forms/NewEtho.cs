﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WpfApp1.Forms
{
    public partial class NewEtho : Form
    {
        public NewEtho()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                if (radioButton5.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/etho.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\claymore\\EthDcrMiner64.exe -epool stratum+tcp://EtherOne.mine-this.com:8008 -ewal " + textBox3.Text + " -epsw " + textBox4.Text + " -allcoins 1 -mport -8080");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/etho.cmd");
                    this.Close();
                }
                else if (radioButton8.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the mine-this.com pool", "Ether-1");
                }
                else if (radioButton11.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the mine-this.com pool", "Ether-1");
                }
            }
            else if (radioButton2.Checked)
            {
                if (radioButton8.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/etho.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\claymore\\EthDcrMiner64.exe -epool stratum+tcp://ether1.ethashmines.com:8009 -ewal " + textBox3.Text + " -epsw " + textBox4.Text + " -allcoins 1 -mport -8080");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/etho.cmd");
                    this.Close();
                }
                else if (radioButton5.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the ethashmines.com pool", "Ether-1");
                }
                else if (radioButton11.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the ethashmines.com pool", "Ether-1");
                }
            }
            else if (radioButton3.Checked)
            {
                if (radioButton11.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/etho.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\claymore\\EthDcrMiner64.exe -epool stratum+tcp://pool.ether1.org:8009 -ewal " + textBox3.Text + " -epsw " + textBox4.Text + " -allcoins 1 -mport -8080");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/etho.cmd");
                    this.Close();
                }
                else if (radioButton5.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the ether1.org pool", "Ether-1");
                }
                else if (radioButton8.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the ether1.org pool", "Ether-1");
                }
            }
            else if (radioButton4.Checked)
            {
                using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/etho.cmd"))
                {
                    objWriter.WriteLine("start C:\\Miner\\Miners\\claymore\\EthDcrMiner64.exe -epool " + "" + textBox1.Text + ":" + textBox2.Text + " -ewal " + textBox3.Text + " -epsw " + textBox4.Text + " -allcoins 1 -mport -8080");
                    objWriter.WriteLine("exit");
                }
                Process.Start("C:/Miner/Configs/etho.cmd");
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Process.Start("https://wallet.ether1.org/");
        }
    }
}
