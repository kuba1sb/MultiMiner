﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WpfApp1.Forms
{
    public partial class NewFreelabit : Form
    {
        public NewFreelabit()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                if (radioButton5.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/freelabit.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight -o 85.214.35.201:1111 -u " + textBox3.Text + " -p " + textBox4.Text + " -i 8080 -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/freelabit.cmd");
                    this.Close();
                }
                else if (radioButton6.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/freelabit.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight -o 85.214.35.201:2222 -u " + textBox3.Text + " -p " + textBox4.Text + " -i 8080 -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/freelabit.cmd");
                    this.Close();
                }
                else if (radioButton7.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/freelabit.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight -o 85.214.35.201:4444 -u " + textBox3.Text + " -p " + textBox4.Text + " -i 8080 -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/freelabit.cmd");
                    this.Close();
                }
                else if (radioButton8.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the freelabit.kiramine.com pool", "Freelabit");
                }
                else if (radioButton9.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the freelabit.kiramine.com pool", "Freelabit");
                }
                else if (radioButton11.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the freelabit.kiramine.com pool", "Freelabit");
                }
                else if (radioButton12.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the freelabit.kiramine.com pool", "Freelabit");
                }
                else if (radioButton13.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the freelabit.kiramine.com pool", "Freelabit");
                }
            }
            else if (radioButton2.Checked)
            {
                if (radioButton8.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/freelabit.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight -o pool.freelabit.baliwae.com:3333 -u " + textBox3.Text + " -p " + textBox4.Text + " -i 8080 -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/freelabit.cmd");
                    this.Close();
                }
                else if (radioButton9.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/freelabit.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight -o pool.freelabit.baliwae.com:5555 -u " + textBox3.Text + " -p " + textBox4.Text + " -i 8080 -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/freelabit.cmd");
                    this.Close();
                }
                else if (radioButton5.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the freelabit.baliwae.com pool", "Freelabit");
                }
                else if (radioButton6.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the freelabit.baliwae.com pool", "Freelabit");
                }
                else if (radioButton7.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the freelabit.baliwae.com pool", "Freelabit");
                }
                else if (radioButton11.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the freelabit.baliwae.com pool", "Freelabit");
                }
                else if (radioButton12.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the freelabit.baliwae.com pool", "Freelabit");
                }
                else if (radioButton13.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the freelabit.baliwae.com pool", "Freelabit");
                }
            }
            else if (radioButton3.Checked)
            {
                if (radioButton11.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/freelabit.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight -o 173.212.213.225:3333 -u " + textBox3.Text + " -p " + textBox4.Text + " -i 8080 -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/freelabit.cmd");
                    this.Close();
                }
                else if (radioButton12.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/freelabit.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight -o 173.212.213.225:5555 -u " + textBox3.Text + " -p " + textBox4.Text + " -i 8080 -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/freelabit.cmd");
                    this.Close();
                }
                else if (radioButton13.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/freelabit.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight -o 173.212.213.225:7777 -u " + textBox3.Text + " -p " + textBox4.Text + " -i 8080 -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/freelabit.cmd");
                    this.Close();
                }
                else if (radioButton5.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the danger4society.de pool", "Freelabit");
                }
                else if (radioButton6.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the danger4society.de pool", "Freelabit");
                }
                else if (radioButton7.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the danger4society.de pool", "Freelabit");
                }
                else if (radioButton8.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the danger4society.de pool", "Freelabit");
                }
                else if (radioButton9.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the danger4society.de pool", "Freelabit");
                }
            }
            else if (radioButton4.Checked)
            {
                using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/freelabit.cmd"))
                {
                    objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight -o " + "" + textBox1.Text + ":" + textBox2.Text + " -u " + textBox3.Text + " -p " + textBox4.Text + " -i 8080 -c C:\\Miner\\config.txt");
                    objWriter.WriteLine("exit");
                }
                Process.Start("C:/Miner/Configs/freelabit.cmd");
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Freelabit/freelabitwallet.exe"))
            {
                System.Diagnostics.Process.Start("C:/Miner/Wallets/Freelabit/freelabitwallet.exe");
            }
            else
            {
                var myForm = new Freelabit();
                myForm.Show();
            }
        }
    }
}
