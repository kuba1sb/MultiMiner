﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WpfApp1.Forms
{
    public partial class NewITNS : Form
    {
        public NewITNS()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                if (radioButton5.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/itns.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency intense -o 45.32.171.89:4444 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/itns.cmd");
                    this.Close();
                }
                else if (radioButton6.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/itns.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency intense -o 45.32.171.89:6666 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/itns.cmd");
                    this.Close();
                }
                else if (radioButton7.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/itns.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency intense -o 45.32.171.89:7777 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/itns.cmd");
                    this.Close();
                }
                else if (radioButton8.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the intensecoin.com pool", "Intense Coin");
                }
                else if (radioButton9.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the intensecoin.com pool", "Intense Coin");
                }
                else if (radioButton10.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the intensecoin.com pool", "Intense Coin");
                }
            }
            else if (radioButton2.Checked)
            {
                if (radioButton8.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/itns.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency intense -o pool.itnspool.net:3333 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/itns.cmd");
                    this.Close();
                }
                else if (radioButton9.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/itns.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency intense -o pool.itnspool.net:5555 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/itns.cmd");
                    this.Close();
                }
                else if (radioButton10.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/itns.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency intense -o pool.itnspool.net:7777 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/itns.cmd");
                    this.Close();
                }
                else if (radioButton5.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the pool.itnspool.net pool", "Intense Coin");
                }
                else if (radioButton6.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the pool.itnspool.net pool", "Intense Coin");
                }
                else if (radioButton7.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the pool.itnspool.net pool", "Intense Coin");
                }
            }
            else if (radioButton4.Checked)
            {
                using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/itns.cmd"))
                {
                    objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency intense -o " + "" + textBox1.Text + ":" + textBox2.Text + " -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                    objWriter.WriteLine("exit");
                }
                Process.Start("C:/Miner/Configs/itns.cmd");
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/ITNS/itns.cmd"))
            {
                System.Diagnostics.Process.Start("C:/Miner/Wallets/ITNS/itns.cmd");
            }
            else
            {
                var myForm = new ITNS();
                myForm.Show();
            }
        }
    }
}
