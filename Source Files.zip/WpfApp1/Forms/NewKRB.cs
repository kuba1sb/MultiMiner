﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WpfApp1.Forms
{
    public partial class NewKRB : Form
    {
        public NewKRB()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                if (radioButton5.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/krb.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency karbo -o cryptonotepool.com:3334 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/krb.cmd");
                    this.Close();
                }
                else if (radioButton6.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/krb.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency karbo -o cryptonotepool.com:5554 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/krb.cmd");
                    this.Close();
                }
                else if (radioButton7.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/krb.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency karbo -o cryptonotepool.com:8884 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/krb.cmd");
                    this.Close();
                }
                else if (radioButton8.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptonotepool.com pool", "Karbo");
                }
                else if (radioButton9.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptonotepool.com pool", "Karbo");
                }
                else if (radioButton10.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptonotepool.com pool", "Karbo");
                }
                else if (radioButton11.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptonotepool.com pool", "Karbo");
                }
                else if (radioButton12.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptonotepool.com pool", "Karbo");
                }
                else if (radioButton13.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptonotepool.com pool", "Karbo");
                }
            }
            else if (radioButton2.Checked)
            {
                if (radioButton8.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/krb.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency karbo -o krb.crypto-coins.club:5555 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/krb.cmd");
                    this.Close();
                }
                else if (radioButton9.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/krb.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency karbo -o krb.crypto-coins.club:6666 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/krb.cmd");
                    this.Close();
                }
                else if (radioButton10.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/krb.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency karbo -o krb.crypto-coins.club:7777 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/krb.cmd");
                    this.Close();
                }
                else if (radioButton5.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the krb.crypto-coins.club pool", "Karbo");
                }
                else if (radioButton6.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the krb.crypto-coins.club pool", "Karbo");
                }
                else if (radioButton7.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the krb.crypto-coins.club pool", "Karbo");
                }
                else if (radioButton11.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the krb.crypto-coins.club pool", "Karbo");
                }
                else if (radioButton12.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the krb.crypto-coins.club pool", "Karbo");
                }
                else if (radioButton13.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the krb.crypto-coins.club pool", "Karbo");
                }
            }
            else if (radioButton3.Checked)
            {
                if (radioButton11.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/krb.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency karbo -o ocukminingpool.com:3334 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/krb.cmd");
                    this.Close();
                }
                else if (radioButton12.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/krb.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency karbo -o ocukminingpool.com:5556 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/krb.cmd");
                    this.Close();
                }
                else if (radioButton13.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/krb.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency karbo -o ocukminingpool.com:7778 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/krb.cmd");
                    this.Close();
                }
                else if (radioButton5.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the ocukminingpool.com pool", "Karbo");
                }
                else if (radioButton6.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the ocukminingpool.com pool", "Karbo");
                }
                else if (radioButton7.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the ocukminingpool.com pool", "Karbo");
                }
                else if (radioButton8.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the ocukminingpool.com pool", "Karbo");
                }
                else if (radioButton9.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the ocukminingpool.com pool", "Karbo");
                }
                else if (radioButton10.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the ocukminingpool.com pool", "Karbo");
                }
            }
            else if (radioButton4.Checked)
            {
                using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/krb.cmd"))
                {
                    objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency karbo -o " + "" + textBox1.Text + ":" + textBox2.Text + " -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                    objWriter.WriteLine("exit");
                }
                Process.Start("C:/Miner/Configs/krb.cmd");
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/KRB/karbowanec.exe"))
            {
                System.Diagnostics.Process.Start("C:/Miner/Wallets/KRB/karbowanec.exe");
            }
            else
            {
                var myForm = new Karbo();
                myForm.Show();
            }
        }
    }
}
