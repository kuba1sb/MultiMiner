﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WpfApp1.Forms
{
    public partial class NewLines : Form
    {
        public NewLines()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                if (radioButton5.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/lines.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency monero7 -o lines.ingest.cryptoknight.cc:50401 -u " + textBox3.Text + " -p " + textBox4.Text + " -i 8080 -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/lines.cmd");
                    this.Close();
                }
                else if (radioButton6.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/lines.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency monero7 -o lines.ingest.cryptoknight.cc:50402 -u " + textBox3.Text + " -p " + textBox4.Text + " -i 8080 -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/lines.cmd");
                    this.Close();
                }
                else if (radioButton7.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/lines.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency monero7 -o lines.ingest.cryptoknight.cc:50403 -u " + textBox3.Text + " -p " + textBox4.Text + " -i 8080 -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/lines.cmd");
                    this.Close();
                }
                else if (radioButton8.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptoknight.cc pool", "Lines");
                }
            }
            else if (radioButton2.Checked)
            {
                if (radioButton8.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/lines.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency monero7 -o lnspool.partyvibe.com:5000 -u " + textBox3.Text + " -p " + textBox4.Text + " -i 8080 -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/lines.cmd");
                    this.Close();
                }
                else if (radioButton5.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the lnspool.partyvibe.com pool", "Lines");
                }
                else if (radioButton6.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the lnspool.partyvibe.com pool", "Lines");
                }
                else if (radioButton7.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the lnspool.partyvibe.com pool", "Lines");
                }
            }
            else if (radioButton4.Checked)
            {
                using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/lines.cmd"))
                {
                    objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency monero7 -o " + "" + textBox1.Text + ":" + textBox2.Text + " -u " + textBox3.Text + " -p " + textBox4.Text + " -i 8080 -c C:\\Miner\\config.txt");
                    objWriter.WriteLine("exit");
                }
                Process.Start("C:/Miner/Configs/lines.cmd");
                this.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Lines/lines.exe"))
            {
                System.Diagnostics.Process.Start("C:/Miner/Wallets/Lines/Lines.exe");
            }
            else
            {
                var myForm = new Lines();
                myForm.Show();
            }
        }
    }
}
