﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WpfApp1.Forms
{
    public partial class NewOMB : Form
    {
        public NewOMB()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                if (radioButton5.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/omb.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight -o ombre.ingest.cryptoknight.cc:5571 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/omb.cmd");
                    this.Close();
                }
                else if (radioButton6.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/omb.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight -o ombre.ingest.cryptoknight.cc:5572 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/omb.cmd");
                    this.Close();
                }
                else if (radioButton7.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/omb.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight -o ombre.ingest.cryptoknight.cc:5573 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/omb.cmd");
                    this.Close();
                }
                else if (radioButton8.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptoknight.cc pool", "Ombre");
                }
                else if (radioButton9.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptoknight.cc pool", "Ombre");
                }
                else if (radioButton10.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptoknight.cc pool", "Ombre");
                }
                else if (radioButton11.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptoknight.cc pool", "Ombre");
                }
                else if (radioButton12.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptoknight.cc pool", "Ombre");
                }
                else if (radioButton13.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptoknight.cc pool", "Ombre");
                }
            }
            else if (radioButton2.Checked)
            {
                if (radioButton8.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/omb.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight -o omb.luckypool.io:5566 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/omb.cmd");
                    this.Close();
                }
                else if (radioButton9.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/omb.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight -o omb.luckypool.io:5577 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/omb.cmd");
                    this.Close();
                }
                else if (radioButton10.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/omb.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight -o omb.luckypool.io:5588 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/omb.cmd");
                    this.Close();
                }
                else if (radioButton5.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the luckypool.io pool", "Ombre");
                }
                else if (radioButton6.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the luckypool.io pool", "Ombre");
                }
                else if (radioButton7.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the luckypool.io pool", "Ombre");
                }
                else if (radioButton11.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the luckypool.io pool", "Ombre");
                }
                else if (radioButton12.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the luckypool.io pool", "Ombre");
                }
                else if (radioButton13.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the luckypool.io pool", "Ombre");
                }
            }
            else if (radioButton3.Checked)
            {
                if (radioButton11.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/omb.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight -o pool.ombre.io:4444 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/omb.cmd");
                    this.Close();
                }
                else if (radioButton12.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/omb.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight -o pool.ombre.io:4446 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/omb.cmd");
                    this.Close();
                }
                else if (radioButton13.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/omb.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight -o pool.ombre.io:4448 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/omb.cmd");
                    this.Close();
                }
                else if (radioButton5.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the pool.ombre.io pool", "Ombre");
                }
                else if (radioButton6.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the pool.ombre.io pool", "Ombre");
                }
                else if (radioButton7.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the pool.ombre.io pool", "Ombre");
                }
                else if (radioButton8.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the pool.ombre.io pool", "Ombre");
                }
                else if (radioButton9.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the pool.ombre.io pool", "Ombre");
                }
                else if (radioButton10.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the pool.ombre.io pool", "Ombre");
                }
            }
            else if (radioButton4.Checked)
            {
                using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/omb.cmd"))
                {
                    objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight -o " + "" + textBox1.Text + ":" + textBox2.Text + " -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                    objWriter.WriteLine("exit");
                }
                Process.Start("C:/Miner/Configs/omb.cmd");
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/OMB/wallet.exe"))
            {
                System.Diagnostics.Process.Start("C:/Miner/Wallets/OMB/wallet.exe");
            }
            else
            {
                var myForm = new OMB();
                myForm.Show();
            }
        }
    }
}
