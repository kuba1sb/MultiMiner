﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WpfApp1.Forms
{
    public partial class NewPirl : Form
    {
        public NewPirl()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                if (radioButton5.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/pirl.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\claymore\\EthDcrMiner64 -epool stratum+tcp://lb.geo.pirlpool.eu:8002 -ewal " + textBox3.Text + " -epsw " + textBox4.Text + " -allpools 1 -allcoins 1 -gser 2");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/pirl.cmd");
                    this.Close();
                }
                else if (radioButton6.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/pirl.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\claymore\\EthDcrMiner64 -epool stratum+tcp://lb.geo.pirlpool.eu:8004 -ewal " + textBox3.Text + " -epsw " + textBox4.Text + " -allpools 1 -allcoins 1 -gser 2");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/pirl.cmd");
                    this.Close();
                }
                else if (radioButton7.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/pirl.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\claymore\\EthDcrMiner64 -epool stratum+tcp://lb.geo.pirlpool.eu:8044 -ewal " + textBox3.Text + " -epsw " + textBox4.Text + " -allpools 1 -allcoins 1 -gser 2");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/pirl.cmd");
                    this.Close();
                }
                else if (radioButton8.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the lb.geo.pirlpool.eu pool", "Pirl");
                }
                else if (radioButton9.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the lb.geo.pirlpool.eu pool", "Pirl");
                }
                else if (radioButton10.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the lb.geo.pirlpool.eu pool", "Pirl");
                }
            }
            else if (radioButton2.Checked)
            {
                if (radioButton8.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/pirl.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\claymore\\EthDcrMiner64 -epool stratum+tcp://pirl.cryptopools.info:8002 -ewal " + textBox3.Text + " -epsw " + textBox4.Text + " -allpools 1 -allcoins 1 -gser 2");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/pirl.cmd");
                    this.Close();
                }
                else if (radioButton9.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/pirl.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\claymore\\EthDcrMiner64 -epool stratum+tcp://pirl.cryptopools.info:8004 -ewal " + textBox3.Text + " -epsw " + textBox4.Text + " -allpools 1 -allcoins 1 -gser 2");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/pirl.cmd");
                    this.Close();
                }
                else if (radioButton10.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/pirl.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\claymore\\EthDcrMiner64 -epool stratum+tcp://pirl.cryptopools.info:8008 -ewal " + textBox3.Text + " -epsw " + textBox4.Text + " -allpools 1 -allcoins 1 -gser 2");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/pirl.cmd");
                    this.Close();
                }
                else if (radioButton5.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptopools.info pool", "Pirl");
                }
                else if (radioButton6.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptopools.info pool", "Pirl");
                }
                else if (radioButton7.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptopools.info pool", "Pirl");
                }
            }
            else if (radioButton4.Checked)
            {
                using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/pirl.cmd"))
                {
                    objWriter.WriteLine("start C:\\Miner\\Miners\\claymore\\EthDcrMiner64 -epool stratum+tcp://" + "" + textBox1.Text + ":" + textBox2.Text + " -ewal " + textBox3.Text + " -epsw " + textBox4.Text + " -allpools 1 -allcoins 1 -gser 2");
                    objWriter.WriteLine("exit");
                }
                Process.Start("C:/Miner/Configs/pirl.cmd");
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Pirl/Pirl-Nautilus-Wallet.exe"))
            {
                System.Diagnostics.Process.Start("C:/Miner/Wallets/Pirl/Pirl-Nautilus-Wallet.exe");
            }
            else
            {
                var myForm = new Pirl();
                myForm.Show();
            }
        }
    }
}
