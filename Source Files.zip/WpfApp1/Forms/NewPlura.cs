﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WpfApp1.Forms
{
    public partial class NewPlura : Form
    {
        public NewPlura()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                if (radioButton5.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/plura.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight -o mine.plurapool.com:3333 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/plura.cmd");
                    this.Close();
                }
                else if (radioButton6.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/plura.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight -o mine.plurapool.com:5555 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/plura.cmd");
                    this.Close();
                }
                else if (radioButton7.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/plura.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight -o mine.plurapool.com:7777 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/plura.cmd");
                    this.Close();
                }
                else if (radioButton8.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the plurapool.com pool", "Pluracoin");
                }
                else if (radioButton9.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the plurapool.com pool", "Pluracoin");
                }
                else if (radioButton10.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the plurapool.com pool", "Pluracoin");
                }
            }
            else if (radioButton2.Checked)
            {
                if (radioButton8.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/plura.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight -o plura.cryptonight.me:3333 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/plura.cmd");
                    this.Close();
                }
                else if (radioButton9.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/plura.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight -o plura.cryptonight.me:5555 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/plura.cmd");
                    this.Close();
                }
                else if (radioButton10.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/plura.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight -o plura.cryptonight.me:7777 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/plura.cmd");
                    this.Close();
                }
                else if (radioButton5.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptonight.me pool", "Pluracoin");
                }
                else if (radioButton6.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptonight.me pool", "Pluracoin");
                }
                else if (radioButton7.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptonight.me pool", "Pluracoin");
                }
            }
            else if (radioButton4.Checked)
            {
                using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/plura.cmd"))
                {
                    objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight -o " + "" + textBox1.Text + ":" + textBox2.Text + " -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                    objWriter.WriteLine("exit");
                }
                Process.Start("C:/Miner/Configs/plura.cmd");
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Plura/PluraCoin.exe"))
            {
                System.Diagnostics.Process.Start("C:/Miner/Wallets/Plura/PluraCoin.exe");
            }
            else
            {
                var myForm = new Plura();
                myForm.Show();
            }
        }
    }
}
