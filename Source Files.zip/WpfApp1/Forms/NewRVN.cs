﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WpfApp1.Forms
{
    public partial class NewRVN : Form
    {
        public NewRVN()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                if (radioButton5.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/rvn.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\ccminer\\ccminer-x64 -a x16r -o stratum+tcp://cryptopool.party:3636 -u " + textBox3.Text + " -p c=RVN -b 127.0.0.1:8080");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/rvn.cmd");
                    this.Close();
                }
                else if (radioButton8.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptopool.party pool", "Raven");
                }
                else if (radioButton9.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptopool.party pool", "Raven");
                }
            }
            else if (radioButton2.Checked)
            {
                if (radioButton8.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/rvn.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\ccminer\\ccminer-x64 -a x16r -o rvn.nibirupool.com:8818 -u " + textBox3.Text + " -p " + textBox4.Text + " -b 127.0.0.1:8080");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/rvn.cmd");
                    this.Close();
                }
                else if (radioButton9.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/rvn.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\ccminer\\ccminer-x64 -a x16r -o rvn.nibirupool.com:9919 -u " + textBox3.Text + " -p " + textBox4.Text + " -b 127.0.0.1:8080");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/rvn.cmd");
                    this.Close();
                }
                else if (radioButton5.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the nibirupool.com pool", "Raven");
                }
            }
            else if (radioButton4.Checked)
            {
                using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/rvn.cmd"))
                {
                    objWriter.WriteLine("start C:\\Miner\\Miners\\ccminer\\ccminer-x64 -a x16r -o " + "" + textBox1.Text + ":" + textBox2.Text + " -u " + textBox3.Text + " -p " + textBox4.Text + " -b 127.0.0.1:8080");
                    objWriter.WriteLine("exit");
                }
                Process.Start("C:/Miner/Configs/rvn.cmd");
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/RVN/raven-qt.exe"))
            {
                System.Diagnostics.Process.Start("C:/Miner/Wallets/RVN/raven-qt.exe");
            }
            else
            {
                var myForm = new RVN();
                myForm.Show();
            }
        }
    }
}
