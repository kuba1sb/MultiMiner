﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WpfApp1.Forms
{
    public partial class NewRecoal : Form
    {
        public NewRecoal()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                if (radioButton5.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/recoal.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight_v7 -o recoal.multiminer.us:3333 -u " + textBox3.Text + " -p " + textBox4.Text + " -i 8080 -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/recoal.cmd");
                    this.Close();
                }
                else if (radioButton6.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/recoal.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight_v7 -o recoal.multiminer.us:4444 -u " + textBox3.Text + " -p " + textBox4.Text + " -i 8080 -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/recoal.cmd");
                    this.Close();
                }
                else if (radioButton7.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/recoal.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight_v7 -o recoal.multiminer.us:5555 -u " + textBox3.Text + " -p " + textBox4.Text + " -i 8080 -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/recoal.cmd");
                    this.Close();
                }
            }
            else if (radioButton4.Checked)
            {
                using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/recoal.cmd"))
                {
                    objWriter.WriteLine("start C:\\Miner\\Miners\\xmr-stak\\xmr-stak --currency cryptonight_v7 -o " + "" + textBox1.Text + ":" + textBox2.Text + " -u " + textBox3.Text + " -p " + textBox4.Text + " -i 8080 -c C:\\Miner\\config.txt");
                    objWriter.WriteLine("exit");
                }
                Process.Start("C:/Miner/Configs/recoal.cmd");
                this.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/ReCoal/recoal.bat"))
            {
                System.Diagnostics.Process.Start("C:/Miner/Wallets/ReCoal/recoal.bat");
            }
            else
            {
                var myForm = new ReCoal();
                myForm.Show();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
