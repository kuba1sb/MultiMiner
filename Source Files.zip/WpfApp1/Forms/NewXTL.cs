﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WpfApp1.Forms
{
    public partial class NewXTL : Form
    {
        public NewXTL()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                if (radioButton5.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/xtl.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xtl-stak\\xtl-stak --currency stellite -o stellite.ingest.cryptoknight.cc:16221 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/xtl.cmd");
                    this.Close();
                }
                else if (radioButton6.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/xtl.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xtl-stak\\xtl-stak --currency stellite -o stellite.ingest.cryptoknight.cc:16222 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/xtl.cmd");
                    this.Close();
                }
                else if (radioButton7.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/xtl.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xtl-stak\\xtl-stak --currency stellite -o stellite.ingest.cryptoknight.cc:16223 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/xtl.cmd");
                    this.Close();
                }
                else if (radioButton8.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptoknight.cc pool", "Stellite");
                }
                else if (radioButton9.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptoknight.cc pool", "Stellite");
                }
                else if (radioButton10.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptoknight.cc pool", "Stellite");
                }
                else if (radioButton11.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptoknight.cc pool", "Stellite");
                }
                else if (radioButton12.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptoknight.cc pool", "Stellite");
                }
                else if (radioButton13.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the cryptoknight.cc pool", "Stellite");
                }
            }
            else if (radioButton2.Checked)
            {
                if (radioButton8.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/xtl.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xtl-stak\\xtl-stak --currency stellite -o communitypool.stellite.cash:6677 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/xtl.cmd");
                    this.Close();
                }
                else if (radioButton9.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/xtl.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xtl-stak\\xtl-stak --currency stellite -o communitypool.stellite.cash:6688 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/xtl.cmd");
                    this.Close();
                }
                else if (radioButton10.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/xtl.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xtl-stak\\xtl-stak --currency stellite -o communitypool.stellite.cash:6699 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/xtl.cmd");
                    this.Close();
                }
                else if (radioButton5.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the stellite.cash pool", "Stellite");
                }
                else if (radioButton6.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the stellite.cash pool", "Stellite");
                }
                else if (radioButton7.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the stellite.cash pool", "Stellite");
                }
                else if (radioButton11.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the stellite.cash pool", "Stellite");
                }
                else if (radioButton12.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the stellite.cash pool", "Stellite");
                }
                else if (radioButton13.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the stellite.cash pool", "Stellite");
                }
            }
            else if (radioButton3.Checked)
            {
                if (radioButton11.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/xtl.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xtl-stak\\xtl-stak --currency stellite -o stellite.miner.rocks:3333 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/xtl.cmd");
                    this.Close();
                }
                else if (radioButton12.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/xtl.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xtl-stak\\xtl-stak --currency stellite -o stellite.miner.rocks:5555 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/xtl.cmd");
                    this.Close();
                }
                else if (radioButton13.Checked)
                {
                    using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/xtl.cmd"))
                    {
                        objWriter.WriteLine("start C:\\Miner\\Miners\\xtl-stak\\xtl-stak --currency stellite -o stellite.miner.rocks:7777 -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                        objWriter.WriteLine("exit");
                    }
                    Process.Start("C:/Miner/Configs/xtl.cmd");
                    this.Close();
                }
                else if (radioButton5.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the miner.rocks pool", "Stellite");
                }
                else if (radioButton6.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the miner.rocks pool", "Stellite");
                }
                else if (radioButton7.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the miner.rocks pool", "Stellite");
                }
                else if (radioButton8.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the miner.rocks pool", "Stellite");
                }
                else if (radioButton9.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the miner.rocks pool", "Stellite");
                }
                else if (radioButton10.Checked)
                {
                    MessageBox.Show("Invalid port selected, please select a port for the miner.rocks pool", "Stellite");
                }
            }
            else if (radioButton4.Checked)
            {
                using (StreamWriter objWriter = new StreamWriter("C:/Miner/Configs/xtl.cmd"))
                {
                    objWriter.WriteLine("start C:\\Miner\\Miners\\xtl-stak\\xtl-stak --currency stellite -o " + "" + textBox1.Text + ":" + textBox2.Text + " -u " + textBox3.Text + " -p " + textBox4.Text + " -c C:\\Miner\\config.txt");
                    objWriter.WriteLine("exit");
                }
                Process.Start("C:/Miner/Configs/xtl.cmd");
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/XTL/StelliteGUIWallet.exe"))
            {
                System.Diagnostics.Process.Start("C:/Miner/Wallets/XTL/StelliteGUIWallet.exe");
            }
            else
            {
                var myForm = new XTL();
                myForm.Show();
            }
        }
    }
}
