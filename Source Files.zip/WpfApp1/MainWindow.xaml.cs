﻿using System.IO;
using System.Diagnostics;
using System.Net;
using System.Windows;
using MahApps.Metro.Controls;
using Ionic.Zip;
using WpfApp1.Forms;
using MahApps.Metro;
using System;
using System.Windows.Media;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace WpfApp1
{
    public partial class MainWindow : MetroWindow
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public class Hashrate
        {
            public List<List<object>> threads { get; set; }
            public List<double?> total { get; set; }
            public double highest { get; set; }
        }

        public class Results
        {
            public int diff_current { get; set; }
            public int shares_good { get; set; }
            public int shares_total { get; set; }
            public double avg_time { get; set; }
            public int hashes_total { get; set; }
            public List<int> best { get; set; }
            public List<object> error_log { get; set; }
        }

        public class Connection
        {
            public string pool { get; set; }
            public int uptime { get; set; }
            public int ping { get; set; }
            public List<object> error_log { get; set; }
        }

        public class RootObject
        {
            public string version { get; set; }
            public Hashrate hashrate { get; set; }
            public Results results { get; set; }
            public Connection connection { get; set; }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void MyTimer_Tick(object sender, EventArgs e)
        {

            Uri urlCheck = new Uri("http://localhost:8080/api.json");
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(urlCheck);
            request.Timeout = 10000;
            try
            {
                WebResponse response = (HttpWebResponse)request.GetResponse();
                WebClient client = new WebClient();
                string dnlad = client.DownloadString("http://localhost:8080/api.json");
                dynamic jsonObject = JsonConvert.DeserializeObject(dnlad);
                int hash_total = jsonObject.hashrate.total[0];
                string pool = jsonObject.connection.pool;
                int uptime = jsonObject.connection.uptime;
                textBox1.Clear();
                textBox1.AppendText(hash_total.ToString() + "h/s");
                textBox2.Clear();
                textBox2.AppendText(pool);
                textBox3.Clear();
                textBox3.AppendText(uptime.ToString() + "sec.");

            }
            catch (Exception)
            {
                textBox1.Text = "0 h/s";
                textBox2.Text = "Waiting For Miner";
                textBox3.Text = "0 sec.";
            }
        }
        
        // Coins Tab
        // Coins Tab Buttons

        private void Button_Click_Coins(object sender, RoutedEventArgs e)
        {
            Flyout3.IsOpen = false;
            Flyout2.IsOpen = false;
            {
                if (Flyout1.IsOpen == true)
                {
                    Flyout1.IsOpen = false;
                }
                else
                    Flyout1.IsOpen = true;
            }
        }

        private void Button_Click_Stop(object sender, RoutedEventArgs e)
        {
            Process.Start("C:/Miner/Stop.exe");
            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer();
            MyTimer.Tick += new EventHandler(MyTimer_Tick);
            MyTimer.Enabled = false;
        }

        // Hamburger Menu Buttons

        private void HamburgerMenuItem_Click(object sender, RoutedEventArgs e)
        {
            Process.Start("http://www.multiminer.us");
        }

        private void HamburgerMenuItem1_Click(object sender, RoutedEventArgs e)
        {
            Process.Start("http://multiminer.us/faq/");
        }

        private void HamburgerMenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            Flyout3.IsOpen = false;
            Flyout1.IsOpen = false;
            {
                if (Flyout2.IsOpen == true)
                {
                    Flyout2.IsOpen = false;
                }
                else
                    Flyout2.IsOpen = true;
            }
        }

        private void HamburgerMenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            Flyout2.IsOpen = false;
            Flyout1.IsOpen = false;
            {
                if (Flyout3.IsOpen == true)
                {
                    Flyout3.IsOpen = false;
                }
                else
                    Flyout3.IsOpen = true;
            }
        }

        private void HamburgerMenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            Process.Start("C:/Miner/wyUpdate.exe");
        }

        private void HamburgerMenuItem_Click_4(object sender, RoutedEventArgs e)
        {
            Tuple<AppTheme, Accent> appStyle = ThemeManager.DetectAppStyle(Application.Current);
            if (Background == Brushes.White)
            {
                ThemeManager.ChangeAppStyle(Application.Current, ThemeManager.GetAccent("Steel"), ThemeManager.GetAppTheme("BaseDark"));
                Background = Brushes.Black;
            }
            else
            {
                Background = Brushes.White;
                ThemeManager.ChangeAppStyle(Application.Current, ThemeManager.GetAccent("Blue"), ThemeManager.GetAppTheme("BaseLight"));
            }
        }

        private void HamburgerMenuItem_Click_5(object sender, RoutedEventArgs e)
        {
            Flyout3.IsOpen = false;
            Flyout2.IsOpen = false;
            {
                if (Flyout1.IsOpen == true)
                {
                    Flyout1.IsOpen = false;
                }
                else
                    Flyout1.IsOpen = true;
            }
        }

        // Featured Coins Buttons

        private void Featured_Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/etho.cmd"))
            {
                Process.Start("C:/Miner/Configs/etho.cmd");
                try
                {
                    if (textBox1.Text != null)
                    {
                        System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                        {
                            Interval = 10000
                        };
                        MyTimer.Tick += new EventHandler(MyTimer_Tick);
                        MyTimer.Enabled = true;
                    }
                }
                catch (Exception)
                {
                    textBox1.Text = "0 h/s";
                    textBox2.Text = "Waiting For Miner";
                    textBox3.Text = "0 sec.";
                }
            }
            else
            {
                var myForm = new NewEtho();
                myForm.Show();
            }
        }

        private void Featured_MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/etho.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/etho.cmd");
            }
            else
            {
                var myForm = new NewEtho();
                myForm.Show();
            }
        }

        private void Featured_Button_Click_2(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/fest.cmd"))
            {
                Process.Start("C:/Miner/Configs/fest.cmd");
                try
                {
                    if (textBox1.Text != null)
                    {
                        System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                        {
                            Interval = 10000
                        };
                        MyTimer.Tick += new EventHandler(MyTimer_Tick);
                        MyTimer.Enabled = true;
                    }
                }
                catch (Exception)
                {
                    textBox1.Text = "0 h/s";
                    textBox2.Text = "Waiting For Miner";
                    textBox3.Text = "0 sec.";
                }
            }
            else
            {
                var myForm = new NewFest();
                myForm.Show();
            }
        }

        private void Featured_MenuItem_Click2(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/fest.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/fest.cmd");
            }
            else
            {
                var myForm = new NewFest();
                myForm.Show();
            }
        }

        private void Featured_Button_Click_3(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/xat.cmd"))
                {
                Process.Start("C:/Miner/Configs/xat.cmd");
                try
                {
                    if (textBox1.Text != null)
                    {
                        System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                        {
                            Interval = 10000
                        };
                        MyTimer.Tick += new EventHandler(MyTimer_Tick);
                        MyTimer.Enabled = true;
                    }
                }
                catch (Exception)
                {
                    textBox1.Text = "0 h/s";
                    textBox2.Text = "Waiting For Miner";
                    textBox3.Text = "0 sec.";
                }
            }
            else
            {
                var myForm = new NewXAT();
                myForm.Show();
            }
        }

        private void Featured_MenuItem_Click3(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/xat.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/xat.cmd");
            }
            else
            {
                var myForm = new NewXAT();
                myForm.Show();
            }
        }

        // New Coins Buttons

        private void New_Button_Click_1(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/arq.cmd"))
                {
                    Process.Start("C:/Miner/Configs/arq.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewARQ();
                    myForm.Show();
                }
            }
        }

        private void New_MenuItem_Click1(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/arq.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/arq.cmd");
            }
            else
            {
                var myForm = new NewARQ();
                myForm.Show();
            }
        }

        private void New_Button_Click_2(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/esn.cmd"))
                {
                    Process.Start("C:/Miner/Configs/esn.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewESN();
                    myForm.Show();
                }
            }
        }

        private void New_MenuItem_Click2(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/esn.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/esn.cmd");
            }
            else
            {
                var myForm = new NewESN();
                myForm.Show();
            }
        }

        private void New_Button_Click_3(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Your Coin Could Be Here! Email info@multiminer.us for details!", "MultiMiner");
        }

        // Coins to Mine Buttons

        private void Button_Click_Alloy(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/alloy.cmd"))
                {
                    Process.Start("C:/Miner/Configs/alloy.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewAlloy();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_Alloy(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/alloy.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/alloy.cmd");
            }
            else
            {
                var myForm = new NewAlloy();
                myForm.Show();
            }
        }

        private void Button_Click_ARQ(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/arq.cmd"))
                {
                    Process.Start("C:/Miner/Configs/arq.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewARQ();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_ARQ(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/arq.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/arq.cmd");
            }
            else
            {
                var myForm = new NewARQ();
                myForm.Show();
            }
        }

        private void Button_Click_BitCoal(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/bitcoal.cmd"))
                {
                    Process.Start("C:/Miner/Configs/bitcoal.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewBitCoal();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_BitCoal(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/bitcoal.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/bitcoal.cmd");
            }
            else
            {
                var myForm = new NewBitCoal();
                myForm.Show();
            }
        }

        private void Button_Click_BTCN(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/btcn.cmd"))
                {
                    Process.Start("C:/Miner/Configs/btcn.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewBTCN();
                    myForm.Show();
                }
            }
        }

        private void MenuItem_Click_BTCN(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/btcn.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/btcn.cmd");
            }
            else
            {
                var myForm = new NewBTCN();
                myForm.Show();
            }
        }

        private void Button_Click_BitTube(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/ipbc.cmd"))
                {
                    Process.Start("C:/Miner/Configs/ipbc.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewBitTube();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_BitTube(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/ipbc.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/ipbc.cmd");
            }
            else
            {
                var myForm = new NewBitTube();
                myForm.Show();
            }
        }

        private void Button_Click_Catalyst(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/xat.cmd"))
                {
                    Process.Start("C:/Miner/Configs/xat.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewXAT();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_Catalyst(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/xat.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/xat.cmd");
            }
            else
            {
                var myForm = new NewXAT();
                myForm.Show();
            }
        }

        private void Button_Click_Crep(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/crep.cmd"))
                {
                    Process.Start("C:/Miner/Configs/crep.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewCrep();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_Crep(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/crep.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/crep.cmd");
            }
            else
            {
                var myForm = new NewCrep();
                myForm.Show();
            }
        }

        private void Button_Click_Dero(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/dero.cmd"))
                {
                    Process.Start("C:/Miner/Configs/dero.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewDero();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_Dero(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/dero.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/dero.cmd");
            }
            else
            {
                var myForm = new NewDero();
                myForm.Show();
            }
        }

        private void Button_Click_DCY(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/dcy.cmd"))
                {
                    Process.Start("C:/Miner/Configs/dcy.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewDCY();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_DCY(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/dcy.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/dcy.cmd");
            }
            else
            {
                var myForm = new NewDCY();
                myForm.Show();
            }
        }

        private void Button_Click_EGEM(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/egem.cmd"))
            {
                Process.Start("C:/Miner/Configs/egem.cmd");
                try
                {
                    if (textBox1.Text != null)
                    {
                        System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                        {
                            Interval = 10000
                        };
                        MyTimer.Tick += new EventHandler(MyTimer_Tick);
                        MyTimer.Enabled = true;
                    }
                }
                catch (Exception)
                {
                    textBox1.Text = "0 h/s";
                    textBox2.Text = "Waiting For Miner";
                    textBox3.Text = "0 sec.";
                }
            }
            else
            {
                var myForm = new NewEGEM();
                myForm.Show();
            }
        }

        private void MenuItem_Click_EGEM(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/egem.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/egem.cmd");
            }
            else
            {
                var myForm = new NewEGEM();
                myForm.Show();
            }
        }

        private void Button_Click_Elya(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/elya.cmd"))
                {
                    Process.Start("C:/Miner/Configs/elya.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewElya();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_Elya(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/elya.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/elya.cmd");
            }
            else
            {
                var myForm = new NewElya();
                myForm.Show();
            }
        }

        private void Button_Click_ESN(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/esn.cmd"))
                {
                    Process.Start("C:/Miner/Configs/esn.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewESN();
                    myForm.Show();
                }
            }
        }

        private void MenuItem_Click_ESN(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/esn.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/esn.cmd");
            }
            else
            {
                var myForm = new NewESN();
                myForm.Show();
            }
        }

        private void Button_Click_ETN(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/etn.cmd"))
                {
                    Process.Start("C:/Miner/Configs/etn.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewETN();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_ETN(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/etn.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/etn.cmd");
            }
            else
            {
                var myForm = new NewETN();
                myForm.Show();
            }
        }

        private void Button_Click_ETHO(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/etho.cmd"))
            {
                Process.Start("C:/Miner/Configs/etho.cmd");
                try
                {
                    if (textBox1.Text != null)
                    {
                        System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                        {
                            Interval = 10000
                        };
                        MyTimer.Tick += new EventHandler(MyTimer_Tick);
                        MyTimer.Enabled = true;
                    }
                }
                catch (Exception)
                {
                    textBox1.Text = "0 h/s";
                    textBox2.Text = "Waiting For Miner";
                    textBox3.Text = "0 sec.";
                }
            }
            else
            {
                var myForm = new NewEtho();
                myForm.Show();
            }
        }

        private void MenuItem_Click_ETHO(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/etho.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/etho.cmd");
            }
            else
            {
                var myForm = new NewEtho();
                myForm.Show();
            }
        }

        private void Button_Click_Festival(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/fest.cmd"))
                {
                    Process.Start("C:/Miner/Configs/fest.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewFest();
                    myForm.Show();
                }
            }
        }

        private void MenuItem_Click_Festival(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/fest.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/fest.cmd");
            }
            else
            {
                var myForm = new NewFest();
                myForm.Show();
            }
        }

        private void Button_Click_Freelabit(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/freelabit.cmd"))
                {
                    Process.Start("C:/Miner/Configs/freelabit.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewFreelabit();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_Freelabit(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/freelabit.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/freelabit.cmd");
            }
            else
            {
                var myForm = new NewFreelabit();
                myForm.Show();
            }
        }

        private void Button_Click_Graft(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/grft.cmd"))
            {
                Process.Start("C:\\Miner\\Configs\\grft.cmd");
                try
                {
                    if (textBox1.Text != null)
                    {
                        System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                        {
                            Interval = 10000
                        };
                        MyTimer.Tick += new EventHandler(MyTimer_Tick);
                        MyTimer.Enabled = true;
                    }
                }
                catch (Exception)
                {
                    System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                    {
                        Interval = 10000
                    };
                    MyTimer.Tick += new EventHandler(MyTimer_Tick);
                    MyTimer.Enabled = true;
                }
            }
            else
            {
                var myForm = new NewGrft();
                myForm.Show();
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_Graft(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/grft.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/grft.cmd");
            }
            else
            {
                var myForm = new NewGrft();
                myForm.Show();
            }
        }

        private void Button_Click_Haven(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/xhv.cmd"))
            {
                Process.Start("C:/Miner/Configs/xhv.cmd");
                try
                {
                    if (textBox1.Text != null)
                    {
                        System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                        {
                            Interval = 10000
                        };
                        MyTimer.Tick += new EventHandler(MyTimer_Tick);
                        MyTimer.Enabled = true;
                    }
                }
                catch (Exception)
                {
                    textBox1.Text = "0 h/s";
                    textBox2.Text = "Waiting For Miner";
                    textBox3.Text = "0 sec.";
                }
            }
            else
            {
                var myForm = new NewXHV();
                myForm.Show();
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_Haven(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/xhv.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/xhv.cmd");
            }
            else
            {
                var myForm = new NewXHV();
                myForm.Show();
            }
        }

        private void Button_Click_IRD(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/ird.cmd"))
                {
                    Process.Start("C:/Miner/Configs/ird.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewIRD();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_IRD(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/ird.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/ird.cmd");
            }
            else
            {
                var myForm = new NewIRD();
                myForm.Show();
            }
        }

        private void Button_Click_ITNS(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/itns.cmd"))
                {
                    Process.Start("C:/Miner/Configs/itns.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewITNS();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_ITNS(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/itns.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/itns.cmd");
            }
            else
            {
                var myForm = new NewITNS();
                myForm.Show();
            }
        }

        private void Button_Click_KRB(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/krb.cmd"))
                {
                    Process.Start("C:/Miner/Configs/krb.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewKRB();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_KRB(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/krb.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/krb.cmd");
            }
            else
            {
                var myForm = new NewKRB();
                myForm.Show();
            }
        }

        private void Button_Click_Lines(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/lines.cmd"))
                {
                    Process.Start("C:/Miner/Configs/lines.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewLines();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_Lines(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/lines.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/lines.cmd");
            }
            else
            {
                var myForm = new NewLines();
                myForm.Show();
            }
        }

        private void Button_Click_MSR(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/msr.cmd"))
                {
                    Process.Start("C:/Miner/Configs/msr.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewMSR();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_MSR(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/msr.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/msr.cmd");
            }
            else
            {
                var myForm = new NewMSR();
                myForm.Show();
            }
        }

        private void Button_Click_Monero(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/xmr.cmd"))
                {
                    Process.Start("C:/Miner/Configs/xmr.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewXMR();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_Monero(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/xmr.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/xmr.cmd");
            }
            else
            {
                var myForm = new NewXMR();
                myForm.Show();
            }
        }

        private void Button_Click_MZT(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/mzt.cmd"))
            {
                Process.Start("C:/Miner/Configs/mzt.cmd");
                try
                {
                    if (textBox1.Text != null)
                    {
                        System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                        {
                            Interval = 10000
                        };
                        MyTimer.Tick += new EventHandler(MyTimer_Tick);
                        MyTimer.Enabled = true;
                    }
                }
                catch (Exception)
                {
                    textBox1.Text = "0 h/s";
                    textBox2.Text = "Waiting For Miner";
                    textBox3.Text = "0 sec.";
                }
            }
            else
            {
                var myForm = new NewMZT();
                myForm.Show();
            }
        }

        private void MenuItem_Click_MZT(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/mzt.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/mzt.cmd");
            }
            else
            {
                var myForm = new NewMZT();
                myForm.Show();
            }
        }

        private void Button_Click_NBR(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/nbr.cmd"))
                {
                    Process.Start("C:/Miner/Configs/nbr.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewNBR();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_NBR(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/nbr.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/nbr.cmd");
            }
            else
            {
                var myForm = new NewNBR();
                myForm.Show();
            }
        }

        private void Button_Click_OMB(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/omb.cmd"))
                {
                    Process.Start("C:/Miner/Configs/omb.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewOMB();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_OMB(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/omb.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/omb.cmd");
            }
            else
            {
                var myForm = new NewOMB();
                myForm.Show();
            }
        }

        private void Button_Click_Pirl(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/pirl.cmd"))
                {
                    Process.Start("C:/Miner/Configs/pirl.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewPirl();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_Pirl(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/pirl.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/pirl.cmd");
            }
            else
            {
                var myForm = new NewPirl();
                myForm.Show();
            }
        }

        private void Button_Click_Plura(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/plura.cmd"))
                {
                    Process.Start("C:/Miner/Configs/plura.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewPlura();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_Plura(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/plura.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/plura.cmd");
            }
            else
            {
                var myForm = new NewPlura();
                myForm.Show();
            }
        }

        private void Button_Click_Raven(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/rvn.cmd"))
                {
                    Process.Start("C:/Miner/Configs/rvn.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewRVN();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_Raven(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/rvn.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/rvn.cmd");
            }
            else
            {
                var myForm = new NewRVN();
                myForm.Show();
            }
        }

        private void Button_Click_Solace(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/solace.cmd"))
                {
                    Process.Start("C:/Miner/Configs/solace.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewSolace();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_Solace(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/solace.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/solcae.cmd");
            }
            else
            {
                var myForm = new NewSolace();
                myForm.Show();
            }
        }

        private void Button_Click_Stellite(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/xtl.cmd"))
                {
                    Process.Start("C:/Miner/Configs/xtl.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewXTL();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_Stellite(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/xtl.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/xtl.cmd");
            }
            else
            {
                var myForm = new NewXTL();
                myForm.Show();
            }
        }

        private void Button_Click_SUP(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/sup.cmd"))
                {
                    Process.Start("C:/Miner/Configs/sup.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewSUP();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_SUP(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/sup.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/sup.cmd");
            }
            else
            {
                var myForm = new NewSUP();
                myForm.Show();
            }
        }

        private void Button_Click_TRTL(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/trtl.cmd"))
                {
                    Process.Start("C:/Miner/Configs/trtl.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewTRTL();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_TRTL(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/trtl.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/trtl.cmd");
            }
            else
            {
                var myForm = new NewTRTL();
                myForm.Show();
            }
        }

        private void Button_Click_Tyche(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/tyche.cmd"))
                {
                    Process.Start("C:/Miner/Configs/tyche.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewTyche();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_Tyche(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/tyche.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/tyche.cmd");
            }
            else
            {
                var myForm = new NewTyche();
                myForm.Show();
            }
        }

        private void Button_Click_XUN(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/xun.cmd"))
                {
                    Process.Start("C:/Miner/Configs/xun.cmd");
                    try
                    {
                        if (textBox1.Text != null)
                        {
                            System.Windows.Forms.Timer MyTimer = new System.Windows.Forms.Timer
                            {
                                Interval = 10000
                            };
                            MyTimer.Tick += new EventHandler(MyTimer_Tick);
                            MyTimer.Enabled = true;
                        }
                    }
                    catch (Exception)
                    {
                        textBox1.Text = "0 h/s";
                        textBox2.Text = "Waiting For Miner";
                        textBox3.Text = "0 sec.";
                    }
                }
                else
                {
                    var myForm = new NewXUN();
                    myForm.Show();
                }
            }
            Flyout1.IsOpen = false;
        }

        private void MenuItem_Click_XUN(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/xun.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/xun.cmd");
            }
            else
            {
                var myForm = new NewXUN();
                myForm.Show();
            }
        }


        // Coin Config Buttons

        private void Button_Click_Alloy_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/alloy.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/alloy.cmd");
                }
                else
                {
                    var myForm = new NewAlloy();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_ARQ_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/arq.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/arq.cmd");
                }
                else
                {
                    var myForm = new NewARQ();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_BitCoal_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/bitcoal.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/bitcoal.cmd");
                }
                else
                {
                    var myForm = new NewBitCoal();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_BTCN_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/btcn.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/btcn.cmd");
                }
                else
                {
                    var myForm = new NewBTCN();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_BitTube_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/ipbc.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/ipbc.cmd");
                }
                else
                {
                    var myForm = new NewBitTube();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_Catalyst_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/xat.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/xat.cmd");
                }
                else
                {
                    var myForm = new NewXAT();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_Crep_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/crep.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/crep.cmd");
                }
                else
                {
                    var myForm = new NewCrep();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_Dero_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/dero.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/dero.cmd");
                }
                else
                {
                    var myForm = new NewDero();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_DCY_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/dcy.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/dcy.cmd");
                }
                else
                {
                    var myForm = new NewDCY();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_EGEM_Config(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/egem.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/egem.cmd");
            }
            else
            {
                var myForm = new NewEGEM();
                myForm.Show();
            }
        }

        private void Button_Click_ETN_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/etn.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/etn.cmd");
                }
                else
                {
                    var myForm = new NewETN();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_Elya_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/elya.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/elya.cmd");
                }
                else
                {
                    var myForm = new NewElya();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_ESN_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/esn.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/esn.cmd");
                }
                else
                {
                    var myForm = new NewESN();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_ETHO_Config(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/etho.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/etho.cmd");
            }
            else
            {
                var myForm = new NewEtho();
                myForm.Show();
            }
        }

        private void Button_Click_Fest_Config(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Configs/fest.cmd"))
            {
                Process.Start("notepad.exe", "C:/Miner/Configs/fest.cmd");
            }
            else
            {
                var myForm = new NewFest();
                myForm.Show();
            }
        }

        private void Button_Click_Freelabit_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/freelabit.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/freelabit.cmd");
                }
                else
                {
                    var myForm = new NewFreelabit();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_Graft_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/grft.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/grft.cmd");
                }
                else
                {
                    var myForm = new NewGrft();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_Haven_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/xhv.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/xhv.cmd");
                }
                else
                {
                    var myForm = new NewXHV();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_ITNS_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/itns.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/itns.cmd");
                }
                else
                {
                    var myForm = new NewITNS();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_IRD_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/ird.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/ird.cmd");
                }
                else
                {
                    var myForm = new NewIRD();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_KRB_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/krb.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/krb.cmd");
                }
                else
                {
                    var myForm = new NewKRB();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_Lines_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/lines.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/lines.cmd");
                }
                else
                {
                    var myForm = new NewLines();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_MSR_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/msr.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/msr.cmd");
                }
                else
                {
                    var myForm = new NewMSR();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_Monero_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/xmr.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/xmr.cmd");
                }
                else
                {
                    var myForm = new NewXMR();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_MZT_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/mzt.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/mzt.cmd");
                }
                else
                {
                    var myForm = new NewMZT();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_NBR_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/nbr.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/nbr.cmd");
                }
                else
                {
                    var myForm = new NewNBR();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_OMB_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/omb.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/omb.cmd");
                }
                else
                {
                    var myForm = new NewOMB();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_Pirl_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/pirl.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/pirl.cmd");
                }
                else
                {
                    var myForm = new NewPirl();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_Plura_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/plura.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/plura.cmd");
                }
                else
                {
                    var myForm = new NewPlura();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_Raven_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/rvn.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/rvn.cmd");
                }
                else
                {
                    var myForm = new NewRVN();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_Solace_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/solace.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/solace.cmd");
                }
                else
                {
                    var myForm = new NewSolace();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_Stellite_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/xtl.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/xtl.cmd");
                }
                else
                {
                    var myForm = new NewXTL();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_SUP_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/sup.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/sup.cmd");
                }
                else
                {
                    var myForm = new NewSUP();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_TRTL_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/trtl.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/trtl.cmd");
                }
                else
                {
                    var myForm = new NewTRTL();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_Tyche_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/tyche.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/tyche.cmd");
                }
                else
                {
                    var myForm = new NewTyche();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        private void Button_Click_XUN_Config(object sender, RoutedEventArgs e)
        {
            {
                if (File.Exists("C:/Miner/Configs/xun.cmd"))
                {
                    Process.Start("notepad.exe", "C:/Miner/Configs/xun.cmd");
                }
                else
                {
                    var myForm = new NewXUN();
                    myForm.Show();
                }
            }
            Flyout2.IsOpen = false;
        }

        //Miner Config File Buttons

        private void Button_Click_CPU_Config(object sender, RoutedEventArgs e)
        {
            Process.Start("notepad.exe", "C:/Miner/cpu.txt");
            Flyout3.IsOpen = false;
        }

        private void Button_Click_AMD_Config(object sender, RoutedEventArgs e)
        {
            Process.Start("notepad.exe", "C:/Miner/amd.txt");
            Flyout3.IsOpen = false;
        }

        private void Button_Click_Nvidia_Config(object sender, RoutedEventArgs e)
        {
            Process.Start("notepad.exe", "C:/Miner/nvidia.txt");
            Flyout3.IsOpen = false;
        }

        private void Button_Click_Pools_Config(object sender, RoutedEventArgs e)
        {
            Process.Start("notepad.exe", "C:/Miner/pools.txt");
            Flyout3.IsOpen = false;
        }

        private void Button_Click_Base_Config(object sender, RoutedEventArgs e)
        {
            Process.Start("notepad.exe", "C:/Miner/config.txt");
            Flyout3.IsOpen = false;
        }

        // Wallets Tab
        // Wallet Buttons

        private void Button_Click_Alloy_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Alloy/AlloyWallet.exe"))
            {
                Process.Start("C:/Miner/Wallets/Alloy/AlloyWallet.exe");
            }
            else
            {
                var myForm = new Alloy();
                myForm.Show();
            }
        }

        private void MenuItem_Click_Alloy_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Alloy/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/Alloy/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_ARQ_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/ARQMA/arq.bat"))
            {
                Process.Start("C:/Miner/Wallets/ARQMA/arq.bat");
            }
            else
            {
                var myForm = new ARQ();
                myForm.Show();
            }
        }

        private void MenuItem_Click_ARQ_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/ARQMA/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/ARQMA/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_BitCoal_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/BitCoal/BitCoalWallet-x64.exe"))
            {
                Process.Start("C:/Miner/Wallets/BitCoal/BitCoalWallet-x64.exe");
            }
            else
            {
                var myForm = new BitCoal();
                myForm.Show();
            }
        }

        private void MenuItem_Click_BitCoal_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/BitCoal/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/BitCoal/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_BTCN_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/BTCN/BitcoinnovaWallet-GUI.exe"))
            {
                Process.Start("C:/Miner/Wallets/BTCN/BitcoinnovaWallet-GUI.exe");
            }
            else
            {
                var myForm = new BTCN();
                myForm.Show();
            }

        }

        private void Button_Click_BitTube_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/IPBC/IPBC-Wallet.exe"))
            {
                Process.Start("C:/Miner/Wallets/IPBC/IPBC-Wallet.exe");
            }
            else
            {
                var myForm = new IPBC();
                myForm.Show();
            }
        }

        private void MenuItem_Click_BitTube_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/IPBC/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/IPBC/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_Catalyst_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/XAT/xat.bat"))
            {
                Process.Start("C:/Miner/Wallets/XAT/xat.bat");
            }
            else
            {
                var myForm = new XAT();
                myForm.Show();
            }
        }

        private void MenuItem_Click_Catalyst_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/XAT/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/XAT/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_Crep_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Crep/CREPGUI.exe"))
            {
                Process.Start("C:/Miner/Wallets/Crep/CREPGUI.exe");
            }
            else
            {
                var myForm = new Crep();
                myForm.Show();
            }
        }

        private void MenuItem_Click_Crep_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Crep/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/Crep/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_Dero_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Dero/dero.cmd"))
            {
                Process.Start("C:/Miner/Wallets/Dero/dero.cmd");
            }
            else
            {
                var myForm = new Dero();
                myForm.Show();
            }
        }

        private void MenuItem_Click_Dero_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Dero/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/Dero/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_DCY_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/DCY/dinastycoinwallet.exe"))
            {
                Process.Start("C:/Miner/Wallets/DCY/dinastycoinwallet.exe");
            }
            else
            {
                var myForm = new DCY();
                myForm.Show();
            }
        }

        private void MenuItem_Click_DCY_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/DCY/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/DCY/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_EGEM_Wallet(object sender, RoutedEventArgs e)
        {
            Process.Start("https://myegemwallet.com/");
        }

        private void Button_Click_ESN_Wallet(object sender, RoutedEventArgs e)
        {
            Process.Start("https://wallet.gonspool.com/");
        }

        private void Button_Click_ETN_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/ETN/ElectroneumGUIWallet.exe"))
            {
                Process.Start("C:/Miner/Wallets/ETN/ElectroneumGUIWallet.exe");
            }
            else
            {
                var myForm = new ETN();
                myForm.Show();
            }
        }

        private void MenuItem_Click_ETN_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/ETN/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/ETN/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_Elya_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Elyacoin/Elyacoin.exe"))
            {
                Process.Start("C:/Miner/Wallets/Elyacoin/Elyacoin.exe");
            }
            else
            {
                var myForm = new Elya();
                myForm.Show();
            }
        }

        private void MenuItem_Click_Elya_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Elyacoin/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/Elyacoin/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_ETHO_Wallet(object sender, RoutedEventArgs e)
        {
            Process.Start("https://wallet.ether1.org/");
        }

        private void Button_Click_Fest_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Fest/fest.bat"))
            {
                Process.Start("C:/Miner/Wallets/Fest/fest.bat");
            }
            else
            {
                var myForm = new Fest();
                myForm.Show();
            }
        }

        private void MenuItem_Click_Fest_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Fest/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/Fest/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_Freelabit_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Freelabit/freelabitwallet.exe"))
            {
                Process.Start("C:/Miner/Wallets/Freelabit/freelabitwallet.exe");
            }
            else
            {
                var myForm = new Freelabit();
                myForm.Show();
            }
        }

        private void MenuItem_Click_Freelabit_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Freelabit/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/Freelabit/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_Graft_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Grft/GraftWallet.exe"))
            {
                Process.Start("C:/Miner/Wallets/Grft/GraftWallet.exe");
            }
            else
            {
                var myForm = new GRFT();
                myForm.Show();
            }
        }

        private void MenuItem_Click_Graft_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Grft/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/Grft/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_Haven_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/XHV/haven-wallet-gui.exe"))
            {
                Process.Start("C:/Miner/Wallets/XHV/haven-wallet-gui.exe");
            }
            else
            {
                var myForm = new Haven();
                myForm.Show();
            }
        }

        private void MenuItem_Click_Haven_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/XHV/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/XHV/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_IRD_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/IRD/Iridium_Wallet.exe"))
            {
                Process.Start("C:/Miner/Wallets/IRD/Iridium_Wallet.exe");
            }
            else
            {
                var myForm = new IRD();
                myForm.Show();
            }
        }

        private void MenuItem_Click_IRD_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/IRD/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/IRD/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_ITNS_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/ITNS/itns.cmd"))
            {
                Process.Start("C:/Miner/Wallets/ITNS/itns.cmd");
            }
            else
            {
                var myForm = new ITNS();
                myForm.Show();
            }
        }

        private void MenuItem_Click_ITNS_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/ITNS/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/ITNS/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_KRB_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/KRB/karbowanec.exe"))
            {
                Process.Start("C:/Miner/Wallets/KRB/karbowanec.exe");
            }
            else
            {
                var myForm = new Karbo();
                myForm.Show();
            }
        }

        private void MenuItem_Click_KRB_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/KRB/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/KRB/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_Lines_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Lines/lines.exe"))
            {
                Process.Start("C:/Miner/Wallets/Lines/Lines.exe");
            }
            else
            {
                var myForm = new Lines();
                myForm.Show();
            }
        }

        private void MenuItem_Click_Lines_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Lines/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/Lines/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_MZT_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/MZT/myztic-wallet-gui.exe"))
            {
                Process.Start("C:/Miner/Wallets/MZT/myztic-wallet-gui.exe");
            }
            else
            {
                var myForm = new MZT();
                myForm.Show();
            }
        }

        private void MenuItem_Click_MZT_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/MZT/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/MZT/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_MSR_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/MSR/masari-wallet-gui.exe"))
            {
                Process.Start("C:/Miner/Wallets/MSR/masari-wallet-gui.exe");
            }
            else
            {
                var myForm = new MSR();
                myForm.Show();
            }
        }

        private void MenuItem_Click_MSR_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/MSR/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/MSR/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_Monero_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/XMR/monero-wallet-gui.exe"))
            {
                Process.Start("C:/Miner/Wallets/XMR/monero-wallet-gui.exe");
            }
            else
            {
                var myForm = new XMR();
                myForm.Show();
            }
        }

        private void MenuItem_Click_Monero_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/XMR/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/XMR/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_NBR_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/NBR/niobio.exe"))
            {
                Process.Start("C:/Miner/Wallets/NBR/niobio.exe");
            }
            else
            {
                var myForm = new NBR();
                myForm.Show();
            }
        }

        private void MenuItem_Click_NBR_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/NBR/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/NBR/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_OMB_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/OMB/wallet.exe"))
            {
                Process.Start("C:/Miner/Wallets/OMB/wallet.exe");
            }
            else
            {
                var myForm = new OMB();
                myForm.Show();
            }
        }

        private void MenuItem_Click_OMB_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/OMB/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/OMB/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_Pirl_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Pirl/Pirl-Nautilus-Wallet.exe"))
            {
                Process.Start("C:/Miner/Wallets/Pirl/Pirl-Nautilus-Wallet.exe");
            }
            else
            {
                var myForm = new Pirl();
                myForm.Show();
            }
        }

        private void MenuItem_Click_Pirl_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Pirl/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/Pirl/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_Plura_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Plura/PluraCoin.exe"))
            {
                Process.Start("C:/Miner/Wallets/Plura/PluraCoin.exe");
            }
            else
            {
                var myForm = new Plura();
                myForm.Show();
            }
        }

        private void MenuItem_Click_Plura_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Plura/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/Plura/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_Raven_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/RVN/raven-qt.exe"))
            {
                Process.Start("C:/Miner/Wallets/RVN/raven-qt.exe");
            }
            else
            {
                var myForm = new RVN();
                myForm.Show();
            }
        }

        private void MenuItem_Click_Raven_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/RVN/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/RVN/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_Solace_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Solace/SolaceGUIWallet.exe"))
            {
                Process.Start("C:/Miner/Wallets/Solace/SolaceGUIWallet.exe");
            }
            else
            {
                var myForm = new Solace();
                myForm.Show();
            }
        }

        private void MenuItem_Click_Solace_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Solace/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/Solace/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_Stellite_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/XTL/Stellite-Wallet-GUI.exe"))
            {
                Process.Start("C:/Miner/Wallets/XTL/Stellite-Wallet-GUI.exe");
            }
            else
            {
                var myForm = new XTL();
                myForm.Show();
            }
        }

        private void MenuItem_Click_Stellite_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/XTL/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/XTL/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_SUP_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/Sup/Superior-wallet-gui.exe"))
            {
                Process.Start("C:/Miner/Wallets/Sup/Superior-wallet-gui.exe");
            }
            else
            {
                var myForm = new SUP();
                myForm.Show();
            }
        }

        private void MenuItem_Click_SUP_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/SUP/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/SUP/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_TRTL_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/TRTL/TurtleCoin-Nest.exe"))
            {
                Process.Start("C:/Miner/Wallets/TRTL/TurtleCoin-Nest.exe");
            }
            else
            {
                var myForm = new TRTL();
                myForm.Show();
            }
        }

        private void MenuItem_Click_TRTL_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/TRTL/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/TRTL/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_Tyche_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/TYCHE/TycheCashGUI.exe"))
            {
                Process.Start("C:/Miner/Wallets/TYCHE/TycheCashGUI.exe");
            }
            else
            {
                var myForm = new TYCHE();
                myForm.Show();
            }
        }

        private void MenuItem_Click_Tyche_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/TYCHE/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/TYCHE/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        private void Button_Click_XUN_Wallet(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/XUN/UltraNoteWallet.exe"))
            {
                Process.Start("C:/Miner/Wallets/XUN/UltraNoteWallet.exe");
            }
            else
            {
                var myForm = new XUN();
                myForm.Show();
            }
        }

        private void MenuItem_Click_XUN_Update(object sender, RoutedEventArgs e)
        {
            if (File.Exists("C:/Miner/Wallets/XUN/wyUpdate.exe"))
            {
                Process.Start("C:/Miner/Wallets/XUN/wyUpdate.exe");
            }
            else
                MessageBox.Show("    Wallet Not Installed", "MultiMiner");
        }

        // Exchanges Tab
        // Exchanges Buttons

        private void Button_Click_58(object sender, RoutedEventArgs e)
        {
            Process.Start("https://tradeogre.com/account");
        }

        private void Button_Click_59(object sender, RoutedEventArgs e)
        {
            Process.Start("https://stocks.exchange/trade");
        }

        private void Button_Click_60(object sender, RoutedEventArgs e)
        {
            Process.Start("https://tradesatoshi.com/");
        }

        private void Button_Click_61(object sender, RoutedEventArgs e)
        {
            Process.Start("https://www.cryptopia.co.nz/Register?referrer=pjrudd");
        }

        private void Button_Click_62(object sender, RoutedEventArgs e)
        {
            Process.Start("https://bittrex.com/");
        }

        private void Button_Click_63(object sender, RoutedEventArgs e)
        {
            Process.Start("https://www.binance.com/");
        }

        private void Button_Click_64(object sender, RoutedEventArgs e)
        {
            Process.Start("https://www.kucoin.com/#/");
        }

        private void Button_Click_65(object sender, RoutedEventArgs e)
        {
            Process.Start("https://www.coinbase.com/join/5a4d4316d60ae001608f8543");
        }

        private void Button_Click_66(object sender, RoutedEventArgs e)
        {
            Process.Start("https://poloniex.com/");
        }

        private void Button_Click_67(object sender, RoutedEventArgs e)
        {
            Process.Start("https://wallet.crypto-bridge.org/dashboard");
        }

        private void Button_Click_68(object sender, RoutedEventArgs e)
        {
            Process.Start("https://altex.exchange/");
        }

        // Info Tab
        // Miner Info Buttons

        private void Button_Click_155(object sender, RoutedEventArgs e)
        {
            Process.Start("https://github.com/tpruvot/ccminer/releases");
        }

        private void Button_Click_156(object sender, RoutedEventArgs e)
        {
            Process.Start("https://github.com/nanopool/Claymore-Dual-Miner/releases");
        }

        private void Button_Click_157(object sender, RoutedEventArgs e)
        {
            Process.Start("https://github.com/sgminer-dev/sgminer/releases");
        }

        private void Button_Click_158(object sender, RoutedEventArgs e)
        {
            Process.Start("https://github.com/stellitecoin/xtl-stak/releases");
        }

        private void Button_Click_159(object sender, RoutedEventArgs e)
        {
            Process.Start("https://github.com/alloyproject/xmr-stak-alloy/releases");
        }

        private void Button_Click_160(object sender, RoutedEventArgs e)
        {
            Process.Start("https://github.com/fireice-uk/xmr-stak/releases");
        }

        // Coin Info Buttons

        private void Button_Click_69(object sender, RoutedEventArgs e)
        {
            Process.Start("https://alloycoin.com/");
        }

        private void Button_Click_166(object sender, RoutedEventArgs e)
        {
            Process.Start("https://arqma.com/");
        }

        private void Button_Click_70(object sender, RoutedEventArgs e)
        {
            Process.Start("https://bitcoal.io/");
        }

        private void Button_Click_176(object sender, RoutedEventArgs e)
        {
            Process.Start("https://bitcointalk.org/index.php?topic=2309303.0");
        }

        private void Button_Click_177(object sender, RoutedEventArgs e)
        {
            Process.Start("https://bitcointalk.org/index.php?topic=4485387");
        }

        private void Button_Click_71(object sender, RoutedEventArgs e)
        {
            Process.Start("https://bitcointalk.org/index.php?topic=2638878.0");
        }

        private void Button_Click_72(object sender, RoutedEventArgs e)
        {
            Process.Start("https://dero.io");
        }

        private void Button_Click_73(object sender, RoutedEventArgs e)
        {
            Process.Start(" http://www.dinastycoin.com/it/");
        }

        private void Button_Click_74(object sender, RoutedEventArgs e)
        {
            Process.Start("https://electroneum.com");
        }

        private void Button_Click_75(object sender, RoutedEventArgs e)
        {
            Process.Start("https://bitcointalk.org/index.php?topic=3118732.0");
        }

        private void Button_Click_179(object sender, RoutedEventArgs e)
        {
            Process.Start("https://bitcointalk.org/index.php?topic=3167940.0");
        }

        private void Button_Click_178(object sender, RoutedEventArgs e)
        {
            Process.Start("https://blog.ethersocial.org/links/");
        }

        private void Button_Click_34(object sender, RoutedEventArgs e)
        {
            Process.Start("https://ether1.org");
        }

        private void Button_Click_161(object sender, RoutedEventArgs e)
        {
            Process.Start("https://bitcointalk.org/index.php?topic=3683049.msg36802128");
        }

        private void Button_Click_76(object sender, RoutedEventArgs e)
        {
            Process.Start("https://freelabit.io");
        }

        private void Button_Click_77(object sender, RoutedEventArgs e)
        {
            Process.Start("https://www.graft.network");
        }

        private void Button_Click_78(object sender, RoutedEventArgs e)
        {
            Process.Start("https://havenprotocol.com");
        }

        private void Button_Click_79(object sender, RoutedEventArgs e)
        {
            Process.Start("https://ipbc.io");
        }

        private void Button_Click_80(object sender, RoutedEventArgs e)
        {
            Process.Start("http://ird.cash");
        }

        private void Button_Click_81(object sender, RoutedEventArgs e)
        {
            Process.Start("https://intensecoin.com");
        }

        private void Button_Click_82(object sender, RoutedEventArgs e)
        {
            Process.Start("https://karbo.io");
        }

        private void Button_Click_83(object sender, RoutedEventArgs e)
        {
            Process.Start("https://bitcointalk.org/index.php?topic=3162385.0");
        }

        private void Button_Click_84(object sender, RoutedEventArgs e)
        {
            Process.Start("https://bitcointalk.org/index.php?topic=4445339.20");
        }

        private void Button_Click_85(object sender, RoutedEventArgs e)
        {
            Process.Start("https://getmasari.org");
        }

        private void Button_Click_86(object sender, RoutedEventArgs e)
        {
            Process.Start("https://getmonero.org");
        }

        private void Button_Click_87(object sender, RoutedEventArgs e)
        {
            Process.Start("https://niobiocash.org/en/");
        }

        private void Button_Click_88(object sender, RoutedEventArgs e)
        {
            Process.Start("https://www.ombre.io");
        }

        private void Button_Click_89(object sender, RoutedEventArgs e)
        {
            Process.Start("https://pirl.io");
        }

        private void Button_Click_90(object sender, RoutedEventArgs e)
        {
            Process.Start("https://pluracoin.org");
        }

        private void Button_Click_91(object sender, RoutedEventArgs e)
        {
            Process.Start("https://ravencoin.org");
        }

        private void Button_Click_92(object sender, RoutedEventArgs e)
        {
            Process.Start("https://www.solace-coin.com/");
        }

        private void Button_Click_94(object sender, RoutedEventArgs e)
        {
            Process.Start("https://stellite.cash");
        }

        private void Button_Click_96(object sender, RoutedEventArgs e)
        {
            Process.Start("http://superior-coin.com");
        }

        private void Button_Click_97(object sender, RoutedEventArgs e)
        {
            Process.Start("https://turtlecoin.lol");
        }

        private void Button_Click_98(object sender, RoutedEventArgs e)
        {
            Process.Start("http://tyche.cash");
        }

        private void Button_Click_99(object sender, RoutedEventArgs e)
        {
            Process.Start("https://ultranote.org");
        }

        // Info Tab
        // Crypto Link Buttons

        private void Button_Click_100(object sender, RoutedEventArgs e)
        {
            Process.Start("https://coinlib.io");
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Process.Start("https://www.cryptunit.com/");
        }

        private void Button_Click_133(object sender, RoutedEventArgs e)
        {
            Process.Start("https://coinmarketcap.com/");
        }

        private void Button_Click_134(object sender, RoutedEventArgs e)
        {
            Process.Start("https://newcpucoins.com/");
        }

        private void Button_Click_135(object sender, RoutedEventArgs e)
        {
            Process.Start("http://minecryptonight.net/");
        }

        // Endorsements Tab
        // Endorsements Buttons

        private void Button_Click_152(object sender, RoutedEventArgs e)
        {
            Process.Start("https://ether1.org/#");
        }

        private void Button_Click_153(object sender, RoutedEventArgs e)
        {
            Process.Start("https://egem.io/");
        }

        private void Button_Click_154(object sender, RoutedEventArgs e)
        {
            Process.Start("https://elyatel.com/");
        }

        private void Button_Click_162(object sender, RoutedEventArgs e)
        {
            Process.Start("https://bitcointalk.org/index.php?topic=3683049.msg36802128");
        }

        private void Button_Click_169(object sender, RoutedEventArgs e)
        {
            Process.Start("https://catalyst.cash/");
        }
    }
}